function updateBadge(enabled) {
  chrome.action.setBadgeText({ text: enabled ? "ON" : "OFF" });
  chrome.action.setBadgeBackgroundColor({ color: enabled ? "#16a34a" : "#666666" });
}

// Load initial state when extension starts
chrome.storage.sync.get(["filterEnabled"], (res) => {
  const enabled = res.filterEnabled !== false;
  updateBadge(enabled);
});

// Toggle when icon clicked
chrome.action.onClicked.addListener((tab) => {
  chrome.storage.sync.get(["filterEnabled"], (res) => {
    const enabled = !(res.filterEnabled !== false);

    chrome.storage.sync.set({ filterEnabled: enabled });
    updateBadge(enabled);

    // Tell page to update immediately
    chrome.tabs.sendMessage(tab.id, {
      type: "TOGGLE_FILTER",
      enabled
    });
  });
});
