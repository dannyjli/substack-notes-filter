(() => {
  const STYLE_ID = "ss-notes-filter-style";

  function applyFilter(enabled) {
    let style = document.getElementById(STYLE_ID);

    if (enabled) {
      if (!style) {
        style = document.createElement("style");
        style.id = STYLE_ID;
        style.textContent = `
          div[role="article"][aria-label="Note"]:not(:has(a[href*="/p/"])) {
            display: none !important;
          }
        `;
        document.documentElement.appendChild(style);
      }
    } else {
      if (style) style.remove();
    }
  }

  // Initial load
  chrome.storage.sync.get(["filterEnabled"], (res) => {
    applyFilter(res.filterEnabled !== false);
  });

  // Listen for toggle from icon click
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "TOGGLE_FILTER") {
      applyFilter(msg.enabled);
    }
  });
})();
